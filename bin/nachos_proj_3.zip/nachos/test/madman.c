// idk what this is glauk was giggling the whole time.
// it gets the addr of '0'
int main() {
    int* ptr = (int*)0;
    printf("%d\n", &ptr);
    return 0;
}
